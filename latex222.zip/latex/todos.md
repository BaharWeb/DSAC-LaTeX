# TODO List
- TODO footer: Chapter name not shown > parameter 1 of chaptermark?
- TODO footer: right (odd) too far left
- TODO bibliography: remove cit. on p.
# DONE List
- DONE A5
- DONE 10pt
- DONE margins: 15mm x 25mm
